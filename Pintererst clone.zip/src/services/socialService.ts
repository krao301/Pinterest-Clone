import apiService from './apiService';
import {
  User,
  Invitation,
  CollaborationRequest,
  ApiResponse,
  PaginatedResponse,
} from '../types';

const axios = apiService.getAxiosInstance();

export const socialService = {
  // Follow user
  followUser: async (userId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/social/follow/${userId}`);
    return response.data;
  },

  // Unfollow user
  unfollowUser: async (userId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/social/follow/${userId}`);
    return response.data;
  },

  // Get followers
  getFollowers: async (userId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<User>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<User>>>(`/social/${userId}/followers`, {
      params: { page, size },
    });
    return response.data;
  },

  // Get following
  getFollowing: async (userId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<User>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<User>>>(`/social/${userId}/following`, {
      params: { page, size },
    });
    return response.data;
  },

  // Send collaboration invitation
  sendInvitation: async (data: CollaborationRequest): Promise<ApiResponse<Invitation>> => {
    const response = await axios.post<ApiResponse<Invitation>>('/social/invitations', data);
    return response.data;
  },

  // Get user's invitations
  getInvitations: async (page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Invitation>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Invitation>>>('/social/invitations', {
      params: { page, size },
    });
    return response.data;
  },

  // Accept invitation
  acceptInvitation: async (invitationId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/social/invitations/${invitationId}/accept`);
    return response.data;
  },

  // Decline invitation
  declineInvitation: async (invitationId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/social/invitations/${invitationId}/decline`);
    return response.data;
  },

  // Block user
  blockUser: async (userId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/social/block/${userId}`);
    return response.data;
  },

  // Report user
  reportUser: async (userId: string, reason: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/social/report/${userId}`, { reason });
    return response.data;
  },
};
