import apiService from './apiService';
import {
  SearchFilters,
  SearchResults,
  ApiResponse,
} from '../types';

const axios = apiService.getAxiosInstance();

export const searchService = {
  // Search pins, boards, and users
  search: async (filters: SearchFilters): Promise<ApiResponse<SearchResults>> => {
    const response = await axios.get<ApiResponse<SearchResults>>('/search', {
      params: filters,
    });
    return response.data;
  },

  // Get search suggestions
  getSuggestions: async (query: string): Promise<ApiResponse<string[]>> => {
    const response = await axios.get<ApiResponse<string[]>>('/search/suggestions', {
      params: { query },
    });
    return response.data;
  },
};
