import apiService from './apiService';
import {
  Pin,
  CreatePinRequest,
  UpdatePinRequest,
  ApiResponse,
  PaginatedResponse,
} from '../types';

const axios = apiService.getAxiosInstance();

export const pinService = {
  // Get all pins (paginated)
  getAllPins: async (page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Pin>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Pin>>>('/pins', {
      params: { page, size },
    });
    return response.data;
  },

  // Get pin by ID
  getPinById: async (pinId: string): Promise<ApiResponse<Pin>> => {
    const response = await axios.get<ApiResponse<Pin>>(`/pins/${pinId}`);
    return response.data;
  },

  // Create new pin
  createPin: async (data: CreatePinRequest): Promise<ApiResponse<Pin>> => {
    const response = await axios.post<ApiResponse<Pin>>('/pins', data);
    return response.data;
  },

  // Update pin
  updatePin: async (pinId: string, data: UpdatePinRequest): Promise<ApiResponse<Pin>> => {
    const response = await axios.put<ApiResponse<Pin>>(`/pins/${pinId}`, data);
    return response.data;
  },

  // Delete pin
  deletePin: async (pinId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/pins/${pinId}`);
    return response.data;
  },

  // Get user's pins
  getUserPins: async (userId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Pin>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Pin>>>(`/users/${userId}/pins`, {
      params: { page, size },
    });
    return response.data;
  },

  // Like pin
  likePin: async (pinId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/pins/${pinId}/like`);
    return response.data;
  },

  // Unlike pin
  unlikePin: async (pinId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/pins/${pinId}/like`);
    return response.data;
  },

  // Upload image
  uploadImage: async (file: File): Promise<ApiResponse<{ imageUrl: string }>> => {
    const formData = new FormData();
    formData.append('image', file);
    const response = await axios.post<ApiResponse<{ imageUrl: string }>>('/pins/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },
};
