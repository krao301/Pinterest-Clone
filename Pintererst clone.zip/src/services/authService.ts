import apiService from './apiService';
import {
  LoginRequest,
  RegisterRequest,
  AuthResponse,
  ApiResponse,
  User,
} from '../types';

const axios = apiService.getAxiosInstance();

export const authService = {
  // Register new user
  register: async (data: RegisterRequest): Promise<ApiResponse<AuthResponse>> => {
    const response = await axios.post<ApiResponse<AuthResponse>>('/auth/register', data);
    return response.data;
  },

  // Login user
  login: async (data: LoginRequest): Promise<ApiResponse<AuthResponse>> => {
    const response = await axios.post<ApiResponse<AuthResponse>>('/auth/login', data);
    if (response.data.success && response.data.data.token) {
      localStorage.setItem('authToken', response.data.data.token);
      localStorage.setItem('user', JSON.stringify(response.data.data.user));
    }
    return response.data;
  },

  // Logout user
  logout: (): void => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
  },

  // Get current user
  getCurrentUser: (): User | null => {
    const userStr = localStorage.getItem('user');
    if (userStr) {
      try {
        return JSON.parse(userStr);
      } catch {
        return null;
      }
    }
    return null;
  },

  // Check if user is authenticated
  isAuthenticated: (): boolean => {
    return !!localStorage.getItem('authToken');
  },

  // Get user profile
  getUserProfile: async (userId: string): Promise<ApiResponse<User>> => {
    const response = await axios.get<ApiResponse<User>>(`/users/${userId}`);
    return response.data;
  },

  // Update user profile
  updateUserProfile: async (userId: string, data: Partial<User>): Promise<ApiResponse<User>> => {
    const response = await axios.put<ApiResponse<User>>(`/users/${userId}`, data);
    return response.data;
  },
};
