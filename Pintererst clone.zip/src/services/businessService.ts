import apiService from './apiService';
import {
  BusinessProfile,
  SponsoredPin,
  Campaign,
  ApiResponse,
  PaginatedResponse,
} from '../types';

const axios = apiService.getAxiosInstance();

export const businessService = {
  // Create business profile
  createBusinessProfile: async (data: Partial<BusinessProfile>): Promise<ApiResponse<BusinessProfile>> => {
    const response = await axios.post<ApiResponse<BusinessProfile>>('/business/profile', data);
    return response.data;
  },

  // Get business profile
  getBusinessProfile: async (userId: string): Promise<ApiResponse<BusinessProfile>> => {
    const response = await axios.get<ApiResponse<BusinessProfile>>(`/business/profile/${userId}`);
    return response.data;
  },

  // Update business profile
  updateBusinessProfile: async (businessId: string, data: Partial<BusinessProfile>): Promise<ApiResponse<BusinessProfile>> => {
    const response = await axios.put<ApiResponse<BusinessProfile>>(`/business/profile/${businessId}`, data);
    return response.data;
  },

  // Get sponsored pins
  getSponsoredPins: async (page: number = 0, size: number = 10): Promise<ApiResponse<PaginatedResponse<SponsoredPin>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<SponsoredPin>>>('/business/sponsored-pins', {
      params: { page, size },
    });
    return response.data;
  },

  // Create campaign
  createCampaign: async (data: Partial<Campaign>): Promise<ApiResponse<Campaign>> => {
    const response = await axios.post<ApiResponse<Campaign>>('/business/campaigns', data);
    return response.data;
  },

  // Get campaigns
  getCampaigns: async (businessId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Campaign>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Campaign>>>(`/business/${businessId}/campaigns`, {
      params: { page, size },
    });
    return response.data;
  },

  // Get campaign by ID
  getCampaignById: async (campaignId: string): Promise<ApiResponse<Campaign>> => {
    const response = await axios.get<ApiResponse<Campaign>>(`/business/campaigns/${campaignId}`);
    return response.data;
  },

  // Update campaign
  updateCampaign: async (campaignId: string, data: Partial<Campaign>): Promise<ApiResponse<Campaign>> => {
    const response = await axios.put<ApiResponse<Campaign>>(`/business/campaigns/${campaignId}`, data);
    return response.data;
  },

  // Delete campaign
  deleteCampaign: async (campaignId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/business/campaigns/${campaignId}`);
    return response.data;
  },
};
