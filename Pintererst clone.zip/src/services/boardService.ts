import apiService from './apiService';
import {
  Board,
  CreateBoardRequest,
  UpdateBoardRequest,
  Pin,
  ApiResponse,
  PaginatedResponse,
} from '../types';

const axios = apiService.getAxiosInstance();

export const boardService = {
  // Get all boards (paginated)
  getAllBoards: async (page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Board>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Board>>>('/boards', {
      params: { page, size },
    });
    return response.data;
  },

  // Get board by ID
  getBoardById: async (boardId: string): Promise<ApiResponse<Board>> => {
    const response = await axios.get<ApiResponse<Board>>(`/boards/${boardId}`);
    return response.data;
  },

  // Create new board
  createBoard: async (data: CreateBoardRequest): Promise<ApiResponse<Board>> => {
    const response = await axios.post<ApiResponse<Board>>('/boards', data);
    return response.data;
  },

  // Update board
  updateBoard: async (boardId: string, data: UpdateBoardRequest): Promise<ApiResponse<Board>> => {
    const response = await axios.put<ApiResponse<Board>>(`/boards/${boardId}`, data);
    return response.data;
  },

  // Delete board
  deleteBoard: async (boardId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/boards/${boardId}`);
    return response.data;
  },

  // Get user's boards
  getUserBoards: async (userId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Board>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Board>>>(`/users/${userId}/boards`, {
      params: { page, size },
    });
    return response.data;
  },

  // Get pins in a board
  getBoardPins: async (boardId: string, page: number = 0, size: number = 20): Promise<ApiResponse<PaginatedResponse<Pin>>> => {
    const response = await axios.get<ApiResponse<PaginatedResponse<Pin>>>(`/boards/${boardId}/pins`, {
      params: { page, size },
    });
    return response.data;
  },

  // Add pin to board
  addPinToBoard: async (boardId: string, pinId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/boards/${boardId}/pins/${pinId}`);
    return response.data;
  },

  // Remove pin from board
  removePinFromBoard: async (boardId: string, pinId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/boards/${boardId}/pins/${pinId}`);
    return response.data;
  },

  // Add collaborator to board
  addCollaborator: async (boardId: string, userId: string): Promise<ApiResponse<void>> => {
    const response = await axios.post<ApiResponse<void>>(`/boards/${boardId}/collaborators/${userId}`);
    return response.data;
  },

  // Remove collaborator from board
  removeCollaborator: async (boardId: string, userId: string): Promise<ApiResponse<void>> => {
    const response = await axios.delete<ApiResponse<void>>(`/boards/${boardId}/collaborators/${userId}`);
    return response.data;
  },
};
