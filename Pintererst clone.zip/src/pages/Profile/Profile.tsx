import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Container, Row, Col, Button, Tabs, Tab, Spinner, Alert } from 'react-bootstrap';
import { authService } from '../../services/authService';
import { pinService } from '../../services/pinService';
import { boardService } from '../../services/boardService';
import { socialService } from '../../services/socialService';
import { User, Pin, Board } from '../../types';
import PinCard from '../../components/PinCard/PinCard';
import BoardCard from '../../components/BoardCard/BoardCard';
import './Profile.css';

const Profile: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [user, setUser] = useState<User | null>(null);
  const [pins, setPins] = useState<Pin[]>([]);
  const [boards, setBoards] = useState<Board[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [following, setFollowing] = useState(false);
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const currentUser = authService.getCurrentUser();
  const isOwnProfile = currentUser?.id === id;

  useEffect(() => {
    if (id) {
      loadProfile();
      loadPins();
      loadBoards();
      loadSocialStats();
    }
  }, [id]);

  const loadProfile = async () => {
    try {
      setLoading(true);
      const response = await authService.getUserProfile(id!);
      if (response.success) {
        setUser(response.data);
      }
    } catch (error: any) {
      setError('Failed to load profile');
    } finally {
      setLoading(false);
    }
  };

  const loadPins = async () => {
    try {
      const response = await pinService.getUserPins(id!);
      if (response.success) {
        setPins(response.data.content);
      }
    } catch (error) {
      console.error('Error loading pins:', error);
    }
  };

  const loadBoards = async () => {
    try {
      const response = await boardService.getUserBoards(id!);
      if (response.success) {
        setBoards(response.data.content);
      }
    } catch (error) {
      console.error('Error loading boards:', error);
    }
  };

  const loadSocialStats = async () => {
    try {
      const [followersRes, followingRes] = await Promise.all([
        socialService.getFollowers(id!),
        socialService.getFollowing(id!),
      ]);
      if (followersRes.success) {
        setFollowersCount(followersRes.data.totalElements);
      }
      if (followingRes.success) {
        setFollowingCount(followingRes.data.totalElements);
      }
    } catch (error) {
      console.error('Error loading social stats:', error);
    }
  };

  const handleFollow = async () => {
    try {
      if (following) {
        await socialService.unfollowUser(id!);
        setFollowing(false);
        setFollowersCount((prev) => prev - 1);
      } else {
        await socialService.followUser(id!);
        setFollowing(true);
        setFollowersCount((prev) => prev + 1);
      }
    } catch (error) {
      console.error('Error toggling follow:', error);
    }
  };

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
      </Container>
    );
  }

  if (error || !user) {
    return (
      <Container className="py-5">
        <Alert variant="danger">{error || 'Profile not found'}</Alert>
      </Container>
    );
  }

  return (
    <Container className="profile-page py-4">
      <div className="profile-header text-center mb-5">
        <div className="profile-avatar mb-3">
          {user.profileImage ? (
            <img src={user.profileImage} alt={user.username} />
          ) : (
            <i className="bi bi-person-circle fs-1"></i>
          )}
        </div>
        <h2 className="profile-username">{user.username}</h2>
        <p className="profile-email text-muted">{user.email}</p>
        {user.bio && <p className="profile-bio">{user.bio}</p>}
        
        {user.isBusinessAccount && (
          <span className="badge bg-primary mb-3">
            <i className="bi bi-briefcase me-1"></i>
            Business Account
          </span>
        )}

        <div className="profile-stats mb-3">
          <div className="stat-item">
            <strong>{followersCount}</strong>
            <span>Followers</span>
          </div>
          <div className="stat-item">
            <strong>{followingCount}</strong>
            <span>Following</span>
          </div>
          <div className="stat-item">
            <strong>{pins.length}</strong>
            <span>Pins</span>
          </div>
        </div>

        {!isOwnProfile && (
          <Button
            variant={following ? 'outline-secondary' : 'danger'}
            onClick={handleFollow}
          >
            {following ? 'Following' : 'Follow'}
          </Button>
        )}
        
        {isOwnProfile && (
          <Button variant="outline-secondary">
            Edit Profile
          </Button>
        )}
      </div>

      <Tabs defaultActiveKey="pins" className="profile-tabs mb-4" justify>
        <Tab eventKey="pins" title={`Pins (${pins.length})`}>
          {pins.length === 0 ? (
            <div className="text-center py-5">
              <i className="bi bi-pin-angle fs-1 text-muted"></i>
              <p className="mt-3 text-muted">No pins yet</p>
            </div>
          ) : (
            <div className="pins-masonry">
              {pins.map((pin) => (
                <PinCard key={pin.id} pin={pin} />
              ))}
            </div>
          )}
        </Tab>
        <Tab eventKey="boards" title={`Boards (${boards.length})`}>
          {boards.length === 0 ? (
            <div className="text-center py-5">
              <i className="bi bi-collection fs-1 text-muted"></i>
              <p className="mt-3 text-muted">No boards yet</p>
            </div>
          ) : (
            <div className="boards-grid">
              {boards.map((board) => (
                <BoardCard key={board.id} board={board} />
              ))}
            </div>
          )}
        </Tab>
      </Tabs>
    </Container>
  );
};

export default Profile;
