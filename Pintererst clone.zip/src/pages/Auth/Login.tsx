import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Container, Row, Col, Form, Button, Alert, Card } from 'react-bootstrap';
import { authService } from '../../services/authService';
import { LoginRequest, CircuitBreakerState } from '../../types';
import './Auth.css';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<LoginRequest>({
    email: '',
    password: '',
  });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [apiError, setApiError] = useState<string>('');
  const [loading, setLoading] = useState(false);
  
  // Circuit breaker state
  const [circuitBreaker, setCircuitBreaker] = useState<CircuitBreakerState>({
    isOpen: false,
    remainingTime: 0,
    failedAttempts: 0,
  });

  useEffect(() => {
    // Check if circuit breaker is open on component mount
    const cbState = localStorage.getItem('circuitBreakerState');
    if (cbState) {
      const state: CircuitBreakerState = JSON.parse(cbState);
      const now = Date.now();
      const openTime = localStorage.getItem('circuitBreakerOpenTime');
      
      if (openTime && state.isOpen) {
        const elapsed = now - parseInt(openTime);
        const remaining = 60000 - elapsed; // 60 seconds in milliseconds
        
        if (remaining > 0) {
          setCircuitBreaker({
            ...state,
            remainingTime: Math.ceil(remaining / 1000),
          });
          startTimer(Math.ceil(remaining / 1000));
        } else {
          // Circuit breaker timeout has passed, reset it
          resetCircuitBreaker();
        }
      }
    }
  }, []);

  const startTimer = (seconds: number) => {
    let timeLeft = seconds;
    const timer = setInterval(() => {
      timeLeft -= 1;
      setCircuitBreaker((prev) => ({
        ...prev,
        remainingTime: timeLeft,
      }));

      if (timeLeft <= 0) {
        clearInterval(timer);
        resetCircuitBreaker();
      }
    }, 1000);
  };

  const resetCircuitBreaker = () => {
    setCircuitBreaker({
      isOpen: false,
      remainingTime: 0,
      failedAttempts: 0,
    });
    localStorage.removeItem('circuitBreakerState');
    localStorage.removeItem('circuitBreakerOpenTime');
    localStorage.removeItem('firstFailedAttemptTime');
  };

  const handleCircuitBreaker = () => {
    const now = Date.now();
    const firstFailTime = localStorage.getItem('firstFailedAttemptTime');
    
    let newFailedAttempts = circuitBreaker.failedAttempts + 1;
    
    if (firstFailTime) {
      const elapsed = now - parseInt(firstFailTime);
      // Reset if more than 30 seconds have passed since first failure
      if (elapsed > 30000) {
        newFailedAttempts = 1;
        localStorage.setItem('firstFailedAttemptTime', now.toString());
      }
    } else {
      localStorage.setItem('firstFailedAttemptTime', now.toString());
    }

    // Open circuit if 3 failed attempts within 30 seconds
    if (newFailedAttempts >= 3) {
      const newState: CircuitBreakerState = {
        isOpen: true,
        remainingTime: 60,
        failedAttempts: newFailedAttempts,
      };
      
      setCircuitBreaker(newState);
      localStorage.setItem('circuitBreakerState', JSON.stringify(newState));
      localStorage.setItem('circuitBreakerOpenTime', now.toString());
      startTimer(60);
      
      setApiError('Too many failed login attempts. Please wait 1 minute before trying again.');
    } else {
      setCircuitBreaker((prev) => ({
        ...prev,
        failedAttempts: newFailedAttempts,
      }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.email) {
      newErrors.email = 'Email is required';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError('');

    if (circuitBreaker.isOpen) {
      setApiError(`Circuit breaker is open. Please wait ${circuitBreaker.remainingTime} seconds.`);
      return;
    }

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const response = await authService.login(formData);
      if (response.success) {
        // Reset circuit breaker on successful login
        resetCircuitBreaker();
        navigate('/dashboard');
      }
    } catch (error: any) {
      handleCircuitBreaker();
      setApiError(error.response?.data?.message || 'Invalid email or password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <Container>
        <Row className="justify-content-center align-items-center min-vh-100">
          <Col md={6} lg={5}>
            <Card className="shadow-lg border-0">
              <Card.Body className="p-5">
                <div className="text-center mb-4">
                  <h1 className="brand-logo">Pinterest</h1>
                  <h4>Welcome back</h4>
                  <p className="text-muted">Log in to see more</p>
                </div>

                {apiError && <Alert variant="danger">{apiError}</Alert>}
                
                {circuitBreaker.isOpen && (
                  <Alert variant="warning">
                    <strong>Circuit Breaker Active</strong>
                    <div className="mt-2">
                      Please wait <strong>{circuitBreaker.remainingTime}</strong> seconds before trying again.
                    </div>
                  </Alert>
                )}

                <Form onSubmit={handleSubmit}>
                  <Form.Group className="mb-3">
                    <Form.Label>Email Address</Form.Label>
                    <Form.Control
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      isInvalid={!!errors.email}
                      placeholder="Enter email"
                      disabled={circuitBreaker.isOpen}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.email}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Form.Group className="mb-4">
                    <Form.Label>Password</Form.Label>
                    <Form.Control
                      type="password"
                      name="password"
                      value={formData.password}
                      onChange={handleChange}
                      isInvalid={!!errors.password}
                      placeholder="Enter password"
                      disabled={circuitBreaker.isOpen}
                    />
                    <Form.Control.Feedback type="invalid">
                      {errors.password}
                    </Form.Control.Feedback>
                  </Form.Group>

                  <Button
                    variant="danger"
                    type="submit"
                    className="w-100 mb-3"
                    size="lg"
                    disabled={loading || circuitBreaker.isOpen}
                  >
                    {loading ? 'Logging in...' : 'Log in'}
                  </Button>

                  <div className="text-center">
                    <small className="text-muted">
                      Not on Pinterest yet?{' '}
                      <Link to="/register" className="text-decoration-none">
                        Sign up
                      </Link>
                    </small>
                  </div>
                </Form>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Login;
