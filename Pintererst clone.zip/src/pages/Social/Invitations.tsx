import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Badge, Spinner, Alert } from 'react-bootstrap';
import { socialService } from '../../services/socialService';
import { Invitation } from '../../types';
import './Invitations.css';

const Invitations: React.FC = () => {
  const [invitations, setInvitations] = useState<Invitation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [processingIds, setProcessingIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadInvitations();
  }, []);

  const loadInvitations = async () => {
    try {
      setLoading(true);
      const response = await socialService.getInvitations();
      if (response.success) {
        setInvitations(response.data.content);
      }
    } catch (error: any) {
      setError('Failed to load invitations');
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async (invitationId: string) => {
    setProcessingIds((prev) => new Set(prev).add(invitationId));
    try {
      await socialService.acceptInvitation(invitationId);
      setInvitations((prev) =>
        prev.map((inv) =>
          inv.id === invitationId ? { ...inv, status: 'accepted' } : inv
        )
      );
    } catch (error) {
      setError('Failed to accept invitation');
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev);
        newSet.delete(invitationId);
        return newSet;
      });
    }
  };

  const handleDecline = async (invitationId: string) => {
    setProcessingIds((prev) => new Set(prev).add(invitationId));
    try {
      await socialService.declineInvitation(invitationId);
      setInvitations((prev) =>
        prev.map((inv) =>
          inv.id === invitationId ? { ...inv, status: 'declined' } : inv
        )
      );
    } catch (error) {
      setError('Failed to decline invitation');
    } finally {
      setProcessingIds((prev) => {
        const newSet = new Set(prev);
        newSet.delete(invitationId);
        return newSet;
      });
    }
  };

  const pendingInvitations = invitations.filter((inv) => inv.status === 'pending');
  const processedInvitations = invitations.filter((inv) => inv.status !== 'pending');

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
        <p className="mt-3">Loading invitations...</p>
      </Container>
    );
  }

  return (
    <Container className="invitations-page py-4">
      <h2 className="mb-4">Invitations</h2>

      {error && <Alert variant="danger" dismissible onClose={() => setError('')}>{error}</Alert>}

      {pendingInvitations.length === 0 && processedInvitations.length === 0 ? (
        <div className="text-center py-5">
          <i className="bi bi-envelope fs-1 text-muted"></i>
          <h4 className="mt-3">No invitations</h4>
          <p className="text-muted">You don't have any board invitations</p>
        </div>
      ) : (
        <>
          {pendingInvitations.length > 0 && (
            <div className="mb-5">
              <h4 className="mb-3">Pending ({pendingInvitations.length})</h4>
              <Row>
                {pendingInvitations.map((invitation) => (
                  <Col key={invitation.id} md={6} lg={4} className="mb-3">
                    <Card className="invitation-card">
                      <Card.Body>
                        <div className="d-flex align-items-center mb-3">
                          <div className="user-avatar-small me-2">
                            <i className="bi bi-person-circle fs-4"></i>
                          </div>
                          <div className="flex-grow-1">
                            <strong>{invitation.fromUsername}</strong>
                            <br />
                            <small className="text-muted">
                              invited you to collaborate
                            </small>
                          </div>
                        </div>
                        <div className="board-info mb-3">
                          <i className="bi bi-collection me-2"></i>
                          <strong>{invitation.boardTitle}</strong>
                        </div>
                        <small className="text-muted d-block mb-3">
                          {new Date(invitation.createdAt).toLocaleDateString()}
                        </small>
                        <div className="d-flex gap-2">
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => handleAccept(invitation.id)}
                            disabled={processingIds.has(invitation.id)}
                            className="flex-grow-1"
                          >
                            {processingIds.has(invitation.id) ? 'Accepting...' : 'Accept'}
                          </Button>
                          <Button
                            variant="outline-secondary"
                            size="sm"
                            onClick={() => handleDecline(invitation.id)}
                            disabled={processingIds.has(invitation.id)}
                            className="flex-grow-1"
                          >
                            {processingIds.has(invitation.id) ? 'Declining...' : 'Decline'}
                          </Button>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          )}

          {processedInvitations.length > 0 && (
            <div>
              <h4 className="mb-3">Previous</h4>
              <Row>
                {processedInvitations.map((invitation) => (
                  <Col key={invitation.id} md={6} lg={4} className="mb-3">
                    <Card className="invitation-card processed">
                      <Card.Body>
                        <div className="d-flex align-items-center mb-3">
                          <div className="user-avatar-small me-2">
                            <i className="bi bi-person-circle fs-4"></i>
                          </div>
                          <div className="flex-grow-1">
                            <strong>{invitation.fromUsername}</strong>
                            <br />
                            <small className="text-muted">
                              invited you to collaborate
                            </small>
                          </div>
                        </div>
                        <div className="board-info mb-3">
                          <i className="bi bi-collection me-2"></i>
                          <strong>{invitation.boardTitle}</strong>
                        </div>
                        <Badge
                          bg={invitation.status === 'accepted' ? 'success' : 'secondary'}
                        >
                          {invitation.status === 'accepted' ? 'Accepted' : 'Declined'}
                        </Badge>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          )}
        </>
      )}
    </Container>
  );
};

export default Invitations;
