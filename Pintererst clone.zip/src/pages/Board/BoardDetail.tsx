import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button, Dropdown, Modal, Form, Spinner, Alert } from 'react-bootstrap';
import { boardService } from '../../services/boardService';
import { Board, Pin } from '../../types';
import PinCard from '../../components/PinCard/PinCard';
import './Board.css';

const BoardDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [board, setBoard] = useState<Board | null>(null);
  const [pins, setPins] = useState<Pin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showEditModal, setShowEditModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [editData, setEditData] = useState({ title: '', description: '' });

  useEffect(() => {
    if (id) {
      loadBoard();
      loadBoardPins();
    }
  }, [id]);

  const loadBoard = async () => {
    try {
      setLoading(true);
      const response = await boardService.getBoardById(id!);
      if (response.success) {
        setBoard(response.data);
        setEditData({
          title: response.data.title,
          description: response.data.description,
        });
      }
    } catch (error: any) {
      setError('Failed to load board');
    } finally {
      setLoading(false);
    }
  };

  const loadBoardPins = async () => {
    try {
      const response = await boardService.getBoardPins(id!);
      if (response.success) {
        setPins(response.data.content);
      }
    } catch (error: any) {
      console.error('Error loading pins:', error);
    }
  };

  const handleEdit = async () => {
    try {
      const response = await boardService.updateBoard(id!, editData);
      if (response.success) {
        setBoard(response.data);
        setShowEditModal(false);
      }
    } catch (error: any) {
      setError('Failed to update board');
    }
  };

  const handleDelete = async () => {
    try {
      await boardService.deleteBoard(id!);
      navigate('/boards');
    } catch (error: any) {
      setError('Failed to delete board');
    }
  };

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
      </Container>
    );
  }

  if (error || !board) {
    return (
      <Container className="py-5">
        <Alert variant="danger">{error || 'Board not found'}</Alert>
      </Container>
    );
  }

  return (
    <Container className="board-detail-page py-4">
      <div className="board-header text-center mb-5">
        {board.coverImage && (
          <div className="board-cover mb-3">
            <img src={board.coverImage} alt={board.title} />
          </div>
        )}
        <div className="d-flex justify-content-center align-items-center gap-3">
          <h1 className="board-title">{board.title}</h1>
          <Dropdown>
            <Dropdown.Toggle variant="light" size="sm">
              <i className="bi bi-three-dots"></i>
            </Dropdown.Toggle>
            <Dropdown.Menu>
              <Dropdown.Item onClick={() => setShowEditModal(true)}>
                <i className="bi bi-pencil me-2"></i>
                Edit Board
              </Dropdown.Item>
              <Dropdown.Item onClick={() => setShowDeleteModal(true)} className="text-danger">
                <i className="bi bi-trash me-2"></i>
                Delete Board
              </Dropdown.Item>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        {board.description && <p className="board-description mt-2">{board.description}</p>}
        <div className="board-meta mt-3">
          <span className="me-3">
            <strong>{board.pinCount}</strong> Pins
          </span>
          <span>
            <i className={`bi ${board.isPublic ? 'bi-globe' : 'bi-lock'} me-1`}></i>
            {board.isPublic ? 'Public' : 'Private'}
          </span>
        </div>
      </div>

      {pins.length === 0 ? (
        <div className="text-center py-5">
          <i className="bi bi-pin-angle fs-1 text-muted"></i>
          <h4 className="mt-3">No pins yet</h4>
          <p className="text-muted">Start adding pins to this board</p>
          <Button variant="danger" onClick={() => navigate('/pin/create')}>
            Create Pin
          </Button>
        </div>
      ) : (
        <div className="pins-masonry">
          {pins.map((pin) => (
            <PinCard key={pin.id} pin={pin} />
          ))}
        </div>
      )}

      {/* Edit Modal */}
      <Modal show={showEditModal} onHide={() => setShowEditModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Board</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3">
              <Form.Label>Title</Form.Label>
              <Form.Control
                type="text"
                value={editData.title}
                onChange={(e) => setEditData({ ...editData, title: e.target.value })}
              />
            </Form.Group>
            <Form.Group>
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={editData.description}
                onChange={(e) => setEditData({ ...editData, description: e.target.value })}
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowEditModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

      {/* Delete Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Delete Board</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete this board? All pins will be removed from this board.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default BoardDetail;
