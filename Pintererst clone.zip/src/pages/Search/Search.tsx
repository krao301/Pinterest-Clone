import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Form, InputGroup, Spinner, Alert, Nav, Tab } from 'react-bootstrap';
import { searchService } from '../../services/searchService';
import { SearchResults, SearchFilters } from '../../types';
import PinCard from '../../components/PinCard/PinCard';
import BoardCard from '../../components/BoardCard/BoardCard';
import UserCard from '../../components/UserCard/UserCard';
import './Search.css';

const Search: React.FC = () => {
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    type: 'all',
    sortBy: 'relevance',
  });
  const [results, setResults] = useState<SearchResults>({
    pins: [],
    boards: [],
    users: [],
  });
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get('q');
    if (queryParam) {
      setFilters((prev) => ({ ...prev, query: queryParam }));
      performSearch(queryParam);
    }
  }, []);

  useEffect(() => {
    if (filters.query.length > 2) {
      const debounce = setTimeout(() => {
        loadSuggestions();
      }, 300);
      return () => clearTimeout(debounce);
    } else {
      setSuggestions([]);
    }
  }, [filters.query]);

  const loadSuggestions = async () => {
    try {
      const response = await searchService.getSuggestions(filters.query);
      if (response.success) {
        setSuggestions(response.data);
        setShowSuggestions(true);
      }
    } catch (error) {
      console.error('Error loading suggestions:', error);
    }
  };

  const performSearch = async (query?: string) => {
    const searchQuery = query || filters.query;
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError('');
    setShowSuggestions(false);

    try {
      const response = await searchService.search({
        ...filters,
        query: searchQuery,
      });
      if (response.success) {
        setResults(response.data);
      }
    } catch (error: any) {
      setError('Failed to perform search');
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch();
  };

  const handleSuggestionClick = (suggestion: string) => {
    setFilters((prev) => ({ ...prev, query: suggestion }));
    setShowSuggestions(false);
    performSearch(suggestion);
  };

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  const totalResults = results.pins.length + results.boards.length + results.users.length;

  return (
    <Container className="search-page py-4">
      <Row className="mb-4">
        <Col lg={8} className="mx-auto">
          <Form onSubmit={handleSearchSubmit}>
            <InputGroup size="lg" className="search-input-group">
              <InputGroup.Text>
                <i className="bi bi-search"></i>
              </InputGroup.Text>
              <Form.Control
                type="text"
                placeholder="Search for pins, boards, or people..."
                value={filters.query}
                onChange={(e) => handleFilterChange('query', e.target.value)}
                onFocus={() => suggestions.length > 0 && setShowSuggestions(true)}
              />
            </InputGroup>
            
            {showSuggestions && suggestions.length > 0 && (
              <div className="search-suggestions">
                {suggestions.map((suggestion, index) => (
                  <div
                    key={index}
                    className="suggestion-item"
                    onClick={() => handleSuggestionClick(suggestion)}
                  >
                    <i className="bi bi-search me-2"></i>
                    {suggestion}
                  </div>
                ))}
              </div>
            )}
          </Form>
        </Col>
      </Row>

      {filters.query && (
        <Row className="mb-4">
          <Col>
            <div className="d-flex justify-content-between align-items-center">
              <h5>
                {loading ? 'Searching...' : `${totalResults} results for "${filters.query}"`}
              </h5>
              <Form.Select
                style={{ width: 'auto' }}
                value={filters.sortBy}
                onChange={(e) => {
                  handleFilterChange('sortBy', e.target.value);
                  performSearch();
                }}
              >
                <option value="relevance">Most Relevant</option>
                <option value="date">Most Recent</option>
                <option value="popularity">Most Popular</option>
              </Form.Select>
            </div>
          </Col>
        </Row>
      )}

      {error && <Alert variant="danger">{error}</Alert>}

      {loading ? (
        <div className="text-center py-5">
          <Spinner animation="border" variant="danger" />
          <p className="mt-3">Searching...</p>
        </div>
      ) : (
        <Tab.Container defaultActiveKey="all">
          <Nav variant="pills" className="mb-4 search-tabs">
            <Nav.Item>
              <Nav.Link eventKey="all" onClick={() => handleFilterChange('type', 'all')}>
                All
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="pins" onClick={() => handleFilterChange('type', 'pins')}>
                Pins ({results.pins.length})
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="boards" onClick={() => handleFilterChange('type', 'boards')}>
                Boards ({results.boards.length})
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="users" onClick={() => handleFilterChange('type', 'users')}>
                People ({results.users.length})
              </Nav.Link>
            </Nav.Item>
          </Nav>

          <Tab.Content>
            <Tab.Pane eventKey="all">
              {totalResults === 0 && filters.query && (
                <div className="text-center py-5">
                  <i className="bi bi-search fs-1 text-muted"></i>
                  <h4 className="mt-3">No results found</h4>
                  <p className="text-muted">Try different keywords</p>
                </div>
              )}
              
              {results.pins.length > 0 && (
                <>
                  <h4 className="mb-3">Pins</h4>
                  <div className="pins-masonry mb-5">
                    {results.pins.map((pin) => (
                      <PinCard key={pin.id} pin={pin} />
                    ))}
                  </div>
                </>
              )}

              {results.boards.length > 0 && (
                <>
                  <h4 className="mb-3">Boards</h4>
                  <div className="boards-grid mb-5">
                    {results.boards.map((board) => (
                      <BoardCard key={board.id} board={board} />
                    ))}
                  </div>
                </>
              )}

              {results.users.length > 0 && (
                <>
                  <h4 className="mb-3">People</h4>
                  <Row>
                    {results.users.map((user) => (
                      <Col key={user.id} md={6} lg={4} className="mb-3">
                        <UserCard user={user} />
                      </Col>
                    ))}
                  </Row>
                </>
              )}
            </Tab.Pane>

            <Tab.Pane eventKey="pins">
              {results.pins.length === 0 ? (
                <div className="text-center py-5">
                  <p className="text-muted">No pins found</p>
                </div>
              ) : (
                <div className="pins-masonry">
                  {results.pins.map((pin) => (
                    <PinCard key={pin.id} pin={pin} />
                  ))}
                </div>
              )}
            </Tab.Pane>

            <Tab.Pane eventKey="boards">
              {results.boards.length === 0 ? (
                <div className="text-center py-5">
                  <p className="text-muted">No boards found</p>
                </div>
              ) : (
                <div className="boards-grid">
                  {results.boards.map((board) => (
                    <BoardCard key={board.id} board={board} />
                  ))}
                </div>
              )}
            </Tab.Pane>

            <Tab.Pane eventKey="users">
              {results.users.length === 0 ? (
                <div className="text-center py-5">
                  <p className="text-muted">No people found</p>
                </div>
              ) : (
                <Row>
                  {results.users.map((user) => (
                    <Col key={user.id} md={6} lg={4} className="mb-3">
                      <UserCard user={user} />
                    </Col>
                  ))}
                </Row>
              )}
            </Tab.Pane>
          </Tab.Content>
        </Tab.Container>
      )}
    </Container>
  );
};

export default Search;
