import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Card, Button, Tabs, Tab, Badge, Spinner, Alert } from 'react-bootstrap';
import { businessService } from '../../services/businessService';
import { authService } from '../../services/authService';
import { BusinessProfile, SponsoredPin, Campaign } from '../../types';
import './BusinessDashboard.css';

const BusinessDashboard: React.FC = () => {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [sponsoredPins, setSponsoredPins] = useState<SponsoredPin[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const currentUser = authService.getCurrentUser();

  useEffect(() => {
    if (currentUser?.isBusinessAccount) {
      loadBusinessData();
    }
  }, []);

  const loadBusinessData = async () => {
    try {
      setLoading(true);
      const [profileRes, pinsRes, campaignsRes] = await Promise.all([
        businessService.getBusinessProfile(currentUser!.id),
        businessService.getSponsoredPins(),
        businessService.getCampaigns(currentUser!.id),
      ]);

      if (profileRes.success) {
        setProfile(profileRes.data);
      }
      if (pinsRes.success) {
        setSponsoredPins(pinsRes.data.content);
      }
      if (campaignsRes.success) {
        setCampaigns(campaignsRes.data.content);
      }
    } catch (error: any) {
      setError('Failed to load business data');
    } finally {
      setLoading(false);
    }
  };

  if (!currentUser?.isBusinessAccount) {
    return (
      <Container className="py-5">
        <Alert variant="warning">
          <h4>Business Account Required</h4>
          <p>You need to convert your account to a business account to access this page.</p>
          <Button variant="primary">Convert to Business Account</Button>
        </Alert>
      </Container>
    );
  }

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
        <p className="mt-3">Loading business dashboard...</p>
      </Container>
    );
  }

  return (
    <Container className="business-dashboard-page py-4">
      {error && <Alert variant="danger" dismissible onClose={() => setError('')}>{error}</Alert>}

      <div className="business-header mb-4">
        <Row className="align-items-center">
          <Col md={8}>
            <h2 className="mb-2">Business Dashboard</h2>
            {profile && (
              <>
                <h4 className="text-muted">{profile.businessName}</h4>
                <p>{profile.description}</p>
                {profile.isVerified && (
                  <Badge bg="primary">
                    <i className="bi bi-check-circle-fill me-1"></i>
                    Verified Business
                  </Badge>
                )}
              </>
            )}
          </Col>
          <Col md={4} className="text-end">
            <Button variant="danger" className="me-2">
              Create Campaign
            </Button>
            <Button variant="outline-secondary">
              Edit Profile
            </Button>
          </Col>
        </Row>
      </div>

      <Row className="business-stats mb-4">
        <Col md={4}>
          <Card className="stat-card">
            <Card.Body>
              <div className="stat-icon">
                <i className="bi bi-eye-fill"></i>
              </div>
              <h3>12.5K</h3>
              <p className="text-muted">Total Views</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="stat-card">
            <Card.Body>
              <div className="stat-icon">
                <i className="bi bi-hand-thumbs-up-fill"></i>
              </div>
              <h3>3.2K</h3>
              <p className="text-muted">Engagements</p>
            </Card.Body>
          </Card>
        </Col>
        <Col md={4}>
          <Card className="stat-card">
            <Card.Body>
              <div className="stat-icon">
                <i className="bi bi-graph-up-arrow"></i>
              </div>
              <h3>+24%</h3>
              <p className="text-muted">Growth</p>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Tabs defaultActiveKey="campaigns" className="business-tabs mb-4">
        <Tab eventKey="campaigns" title={`Campaigns (${campaigns.length})`}>
          {campaigns.length === 0 ? (
            <div className="text-center py-5">
              <i className="bi bi-megaphone fs-1 text-muted"></i>
              <h4 className="mt-3">No campaigns yet</h4>
              <p className="text-muted">Create your first advertising campaign</p>
              <Button variant="danger">Create Campaign</Button>
            </div>
          ) : (
            <Row>
              {campaigns.map((campaign) => (
                <Col key={campaign.id} md={6} lg={4} className="mb-3">
                  <Card className="campaign-card">
                    <Card.Body>
                      <div className="d-flex justify-content-between align-items-start mb-3">
                        <h5>{campaign.name}</h5>
                        <Badge
                          bg={
                            campaign.status === 'active'
                              ? 'success'
                              : campaign.status === 'paused'
                              ? 'warning'
                              : 'secondary'
                          }
                        >
                          {campaign.status}
                        </Badge>
                      </div>
                      <p className="text-muted">{campaign.description}</p>
                      <div className="campaign-meta">
                        <small className="d-block">
                          <strong>Budget:</strong> ${campaign.budget}
                        </small>
                        <small className="d-block">
                          <strong>Duration:</strong>{' '}
                          {new Date(campaign.startDate).toLocaleDateString()} -{' '}
                          {new Date(campaign.endDate).toLocaleDateString()}
                        </small>
                        <small className="d-block">
                          <strong>Sponsored Pins:</strong> {campaign.sponsoredPins.length}
                        </small>
                      </div>
                      <div className="mt-3">
                        <Button variant="outline-primary" size="sm" className="me-2">
                          View Details
                        </Button>
                        <Button variant="outline-secondary" size="sm">
                          Edit
                        </Button>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              ))}
            </Row>
          )}
        </Tab>

        <Tab eventKey="sponsored" title={`Sponsored Pins (${sponsoredPins.length})`}>
          {sponsoredPins.length === 0 ? (
            <div className="text-center py-5">
              <i className="bi bi-pin-angle fs-1 text-muted"></i>
              <h4 className="mt-3">No sponsored pins</h4>
              <p className="text-muted">Create sponsored pins to promote your content</p>
            </div>
          ) : (
            <div className="pins-masonry">
              {sponsoredPins.map((pin) => (
                <div key={pin.id} className="sponsored-pin-card">
                  <img src={pin.imageUrl} alt={pin.title} />
                  <div className="sponsored-pin-overlay">
                    <h6>{pin.title}</h6>
                    <Badge bg="dark">Sponsored</Badge>
                  </div>
                  <div className="sponsored-pin-stats">
                    <small>
                      <i className="bi bi-eye me-1"></i>
                      1.2K views
                    </small>
                    <small>
                      <i className="bi bi-hand-thumbs-up me-1"></i>
                      234 likes
                    </small>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Tab>

        <Tab eventKey="analytics" title="Analytics">
          <Card>
            <Card.Body className="text-center py-5">
              <i className="bi bi-graph-up fs-1 text-muted"></i>
              <h4 className="mt-3">Analytics Dashboard</h4>
              <p className="text-muted">
                Detailed analytics and performance metrics will be displayed here
              </p>
            </Card.Body>
          </Card>
        </Tab>
      </Tabs>
    </Container>
  );
};

export default BusinessDashboard;
