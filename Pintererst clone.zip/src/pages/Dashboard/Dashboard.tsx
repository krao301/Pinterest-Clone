import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Spinner, Alert, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import { pinService } from '../../services/pinService';
import { businessService } from '../../services/businessService';
import { Pin, SponsoredPin } from '../../types';
import PinCard from '../../components/PinCard/PinCard';
import './Dashboard.css';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [pins, setPins] = useState<Pin[]>([]);
  const [sponsoredPins, setSponsoredPins] = useState<SponsoredPin[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [page, setPage] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  useEffect(() => {
    loadPins();
    loadSponsoredPins();
  }, []);

  const loadPins = async (pageNum: number = 0) => {
    try {
      setLoading(true);
      const response = await pinService.getAllPins(pageNum, 20);
      if (response.success) {
        if (pageNum === 0) {
          setPins(response.data.content);
        } else {
          setPins((prev) => [...prev, ...response.data.content]);
        }
        setHasMore(pageNum < response.data.totalPages - 1);
        setPage(pageNum);
      }
    } catch (error: any) {
      setError('Failed to load pins');
    } finally {
      setLoading(false);
    }
  };

  const loadSponsoredPins = async () => {
    try {
      const response = await businessService.getSponsoredPins(0, 5);
      if (response.success) {
        setSponsoredPins(response.data.content);
      }
    } catch (error) {
      console.error('Error loading sponsored pins:', error);
    }
  };

  const loadMore = () => {
    if (hasMore && !loading) {
      loadPins(page + 1);
    }
  };

  // Merge sponsored pins into regular pins at intervals
  const mergedPins = React.useMemo(() => {
    const merged: (Pin | SponsoredPin)[] = [...pins];
    sponsoredPins.forEach((sponsoredPin, index) => {
      const position = (index + 1) * 8; // Insert every 8 pins
      if (position < merged.length) {
        merged.splice(position, 0, sponsoredPin);
      } else {
        merged.push(sponsoredPin);
      }
    });
    return merged;
  }, [pins, sponsoredPins]);

  if (loading && pins.length === 0) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
        <p className="mt-3">Loading your feed...</p>
      </Container>
    );
  }

  return (
    <Container fluid className="dashboard-page">
      {error && <Alert variant="danger">{error}</Alert>}
      
      <div className="welcome-banner text-center py-4">
        <h2>Discover ideas to try</h2>
        <p className="text-muted">Explore pins from people you follow and topics you love</p>
      </div>

      {mergedPins.length === 0 ? (
        <div className="text-center py-5">
          <i className="bi bi-pin-angle fs-1 text-muted"></i>
          <h4 className="mt-3">No pins to show</h4>
          <p className="text-muted">Start exploring or create your first pin</p>
          <Button variant="danger" onClick={() => navigate('/pin/create')}>
            Create Pin
          </Button>
        </div>
      ) : (
        <>
          <div className="pins-masonry">
            {mergedPins.map((pin, index) => (
              <PinCard key={`${pin.id}-${index}`} pin={pin} />
            ))}
          </div>

          {hasMore && (
            <div className="text-center py-4">
              <Button variant="outline-danger" onClick={loadMore} disabled={loading}>
                {loading ? 'Loading...' : 'Load More'}
              </Button>
            </div>
          )}
        </>
      )}
    </Container>
  );
};

export default Dashboard;
