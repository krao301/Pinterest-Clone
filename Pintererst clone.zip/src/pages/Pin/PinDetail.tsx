import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Button, Dropdown, Modal, Spinner, Alert } from 'react-bootstrap';
import { pinService } from '../../services/pinService';
import { authService } from '../../services/authService';
import { Pin } from '../../types';
import './Pin.css';

const PinDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [pin, setPin] = useState<Pin | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(0);
  const currentUser = authService.getCurrentUser();

  useEffect(() => {
    if (id) {
      loadPin();
    }
  }, [id]);

  const loadPin = async () => {
    try {
      setLoading(true);
      const response = await pinService.getPinById(id!);
      if (response.success) {
        setPin(response.data);
        setLikes(response.data.likes);
      }
    } catch (error: any) {
      setError('Failed to load pin');
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async () => {
    if (!pin) return;
    
    try {
      if (liked) {
        await pinService.unlikePin(pin.id);
        setLiked(false);
        setLikes((prev) => prev - 1);
      } else {
        await pinService.likePin(pin.id);
        setLiked(true);
        setLikes((prev) => prev + 1);
      }
    } catch (error) {
      console.error('Error toggling like:', error);
    }
  };

  const handleEdit = () => {
    navigate(`/pin/edit/${pin?.id}`);
  };

  const handleDelete = async () => {
    if (!pin) return;

    setDeleting(true);
    try {
      await pinService.deletePin(pin.id);
      navigate('/dashboard');
    } catch (error: any) {
      setError('Failed to delete pin');
    } finally {
      setDeleting(false);
      setShowDeleteModal(false);
    }
  };

  const handleVisitSource = () => {
    if (pin?.sourceUrl) {
      window.open(pin.sourceUrl, '_blank');
    }
  };

  const isOwner = currentUser && pin && currentUser.id === pin.userId;

  if (loading) {
    return (
      <Container className="text-center py-5">
        <Spinner animation="border" variant="danger" />
        <p className="mt-3">Loading pin...</p>
      </Container>
    );
  }

  if (error || !pin) {
    return (
      <Container className="py-5">
        <Alert variant="danger">{error || 'Pin not found'}</Alert>
        <Button variant="primary" onClick={() => navigate('/dashboard')}>
          Back to Home
        </Button>
      </Container>
    );
  }

  return (
    <Container className="pin-detail-page py-5">
      <Row className="justify-content-center">
        <Col lg={10}>
          <div className="pin-detail-card shadow-lg">
            <Row className="g-0">
              <Col md={6} className="pin-image-col">
                <div className="pin-image-wrapper">
                  <img src={pin.imageUrl} alt={pin.title} className="pin-image" />
                  {pin.isSponsored && (
                    <div className="sponsored-badge">
                      <span>Sponsored</span>
                    </div>
                  )}
                </div>
              </Col>

              <Col md={6} className="pin-info-col">
                <div className="pin-info-content p-4">
                  <div className="d-flex justify-content-between align-items-start mb-3">
                    <div className="flex-grow-1">
                      {pin.sourceUrl && (
                        <Button
                          variant="link"
                          className="p-0 text-decoration-none mb-2"
                          onClick={handleVisitSource}
                        >
                          <i className="bi bi-box-arrow-up-right me-2"></i>
                          {new URL(pin.sourceUrl).hostname}
                        </Button>
                      )}
                    </div>

                    {isOwner && (
                      <Dropdown>
                        <Dropdown.Toggle variant="light" size="sm">
                          <i className="bi bi-three-dots"></i>
                        </Dropdown.Toggle>
                        <Dropdown.Menu align="end">
                          <Dropdown.Item onClick={handleEdit}>
                            <i className="bi bi-pencil me-2"></i>
                            Edit
                          </Dropdown.Item>
                          <Dropdown.Item
                            onClick={() => setShowDeleteModal(true)}
                            className="text-danger"
                          >
                            <i className="bi bi-trash me-2"></i>
                            Delete
                          </Dropdown.Item>
                        </Dropdown.Menu>
                      </Dropdown>
                    )}
                  </div>

                  <h2 className="pin-title mb-3">{pin.title}</h2>

                  {pin.description && (
                    <p className="pin-description mb-4">{pin.description}</p>
                  )}

                  <div className="pin-metadata mb-4">
                    <div className="d-flex align-items-center mb-3">
                      <div className="user-avatar me-2">
                        <i className="bi bi-person-circle fs-3"></i>
                      </div>
                      <div>
                        <strong>{pin.username}</strong>
                        <br />
                        <small className="text-muted">
                          {new Date(pin.createdAt).toLocaleDateString()}
                        </small>
                      </div>
                    </div>
                  </div>

                  <div className="pin-actions d-flex gap-2 mb-4">
                    <Button
                      variant={liked ? 'danger' : 'outline-danger'}
                      onClick={handleLike}
                      className="flex-grow-1"
                    >
                      <i className={`bi ${liked ? 'bi-heart-fill' : 'bi-heart'} me-2`}></i>
                      {likes} {likes === 1 ? 'Like' : 'Likes'}
                    </Button>
                    <Button variant="outline-secondary">
                      <i className="bi bi-share me-2"></i>
                      Share
                    </Button>
                  </div>

                  <div className="pin-visibility">
                    <small className="text-muted">
                      <i className={`bi ${pin.isPublic ? 'bi-globe' : 'bi-lock'} me-2`}></i>
                      {pin.isPublic ? 'Public' : 'Private'}
                    </small>
                  </div>
                </div>
              </Col>
            </Row>
          </div>
        </Col>
      </Row>

      {/* Delete Confirmation Modal */}
      <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Delete Pin</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          Are you sure you want to delete this pin? This action cannot be undone.
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
            Cancel
          </Button>
          <Button variant="danger" onClick={handleDelete} disabled={deleting}>
            {deleting ? 'Deleting...' : 'Delete'}
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default PinDetail;
