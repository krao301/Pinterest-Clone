import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Container, Row, Col, Form, Button, Alert, Card, Spinner } from 'react-bootstrap';
import { pinService } from '../../services/pinService';
import { boardService } from '../../services/boardService';
import { CreatePinRequest, Board } from '../../types';
import './Pin.css';

const CreatePin: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<CreatePinRequest>({
    title: '',
    description: '',
    imageUrl: '',
    sourceUrl: '',
    isPublic: true,
    boardId: '',
  });
  const [boards, setBoards] = useState<Board[]>([]);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [apiError, setApiError] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [isDraft, setIsDraft] = useState(false);

  useEffect(() => {
    loadUserBoards();
    // Load draft if exists
    const draft = localStorage.getItem('pinDraft');
    if (draft) {
      setFormData(JSON.parse(draft));
      setIsDraft(true);
    }
  }, []);

  const loadUserBoards = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      const response = await boardService.getUserBoards(user.id);
      if (response.success) {
        setBoards(response.data.content);
      }
    } catch (error) {
      console.error('Error loading boards:', error);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    
    setFormData((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: '',
      }));
    }
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setErrors((prev) => ({ ...prev, image: 'Please select an image file' }));
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setErrors((prev) => ({ ...prev, image: 'Image size should be less than 5MB' }));
      return;
    }

    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));

    // Upload image
    setUploadingImage(true);
    try {
      const response = await pinService.uploadImage(file);
      if (response.success) {
        setFormData((prev) => ({
          ...prev,
          imageUrl: response.data.imageUrl,
        }));
      }
    } catch (error: any) {
      setErrors((prev) => ({ ...prev, image: 'Failed to upload image' }));
    } finally {
      setUploadingImage(false);
    }
  };

  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.imageUrl) {
      newErrors.image = 'Please upload an image';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const saveDraft = () => {
    localStorage.setItem('pinDraft', JSON.stringify(formData));
    setIsDraft(true);
    setApiError('');
    // Show success message (you can implement a toast notification here)
    console.log('Draft saved successfully!');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError('');

    if (!validateForm()) {
      return;
    }

    setLoading(true);
    try {
      const response = await pinService.createPin(formData);
      if (response.success) {
        // Clear draft
        localStorage.removeItem('pinDraft');
        navigate(`/pin/${response.data.id}`);
      }
    } catch (error: any) {
      setApiError(error.response?.data?.message || 'Failed to create pin. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handlePreview = () => {
    if (!validateForm()) {
      return;
    }
    // Open preview modal or navigate to preview page
    window.open(`/pin/preview?data=${encodeURIComponent(JSON.stringify(formData))}`, '_blank');
  };

  return (
    <Container className="create-pin-page py-5">
      <Row className="justify-content-center">
        <Col lg={8}>
          <Card className="shadow-lg border-0">
            <Card.Body className="p-4">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h2>Create Pin</h2>
                {isDraft && <span className="badge bg-warning">Draft</span>}
              </div>

              {apiError && <Alert variant="danger">{apiError}</Alert>}

              <Form onSubmit={handleSubmit}>
                <Row>
                  <Col md={5}>
                    <div className="image-upload-section">
                      <Form.Group className="mb-3">
                        <Form.Label>Image</Form.Label>
                        <div className="image-upload-area">
                          {imagePreview ? (
                            <div className="image-preview">
                              <img src={imagePreview} alt="Preview" />
                              {uploadingImage && (
                                <div className="upload-overlay">
                                  <Spinner animation="border" variant="light" />
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="upload-placeholder">
                              <i className="bi bi-cloud-upload fs-1"></i>
                              <p>Click to upload</p>
                              <small>Recommendation: Use high-quality .jpg files less than 5MB</small>
                            </div>
                          )}
                          <Form.Control
                            type="file"
                            accept="image/*"
                            onChange={handleImageChange}
                            className="d-none"
                            id="imageInput"
                          />
                          <label htmlFor="imageInput" className="upload-label"></label>
                        </div>
                        {errors.image && (
                          <small className="text-danger">{errors.image}</small>
                        )}
                      </Form.Group>
                    </div>
                  </Col>

                  <Col md={7}>
                    <Form.Group className="mb-3">
                      <Form.Label>Title</Form.Label>
                      <Form.Control
                        type="text"
                        name="title"
                        value={formData.title}
                        onChange={handleChange}
                        isInvalid={!!errors.title}
                        placeholder="Add your title"
                        maxLength={100}
                      />
                      <Form.Control.Feedback type="invalid">
                        {errors.title}
                      </Form.Control.Feedback>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Description</Form.Label>
                      <Form.Control
                        as="textarea"
                        rows={4}
                        name="description"
                        value={formData.description}
                        onChange={handleChange}
                        placeholder="Tell everyone what your Pin is about"
                        maxLength={500}
                      />
                      <small className="text-muted">
                        {formData.description.length}/500
                      </small>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Source URL (Optional)</Form.Label>
                      <Form.Control
                        type="url"
                        name="sourceUrl"
                        value={formData.sourceUrl}
                        onChange={handleChange}
                        placeholder="Add a link to the source"
                      />
                      <small className="text-muted">
                        Add the website URL for this pin
                      </small>
                    </Form.Group>

                    <Form.Group className="mb-3">
                      <Form.Label>Board (Optional)</Form.Label>
                      <Form.Select
                        name="boardId"
                        value={formData.boardId}
                        onChange={handleChange}
                      >
                        <option value="">Select a board</option>
                        {boards.map((board) => (
                          <option key={board.id} value={board.id}>
                            {board.title}
                          </option>
                        ))}
                      </Form.Select>
                    </Form.Group>

                    <Form.Group className="mb-4">
                      <Form.Check
                        type="switch"
                        id="isPublic"
                        name="isPublic"
                        label="Make this pin public"
                        checked={formData.isPublic}
                        onChange={handleChange}
                      />
                      <small className="text-muted">
                        {formData.isPublic
                          ? 'Everyone can see this pin'
                          : 'Only you can see this pin'}
                      </small>
                    </Form.Group>

                    <div className="d-flex gap-2">
                      <Button
                        variant="outline-secondary"
                        onClick={saveDraft}
                        disabled={loading}
                      >
                        Save Draft
                      </Button>
                      <Button
                        variant="outline-primary"
                        onClick={handlePreview}
                        disabled={loading || !formData.imageUrl}
                      >
                        Preview
                      </Button>
                      <Button
                        variant="danger"
                        type="submit"
                        disabled={loading || uploadingImage}
                        className="ms-auto"
                      >
                        {loading ? 'Publishing...' : 'Publish'}
                      </Button>
                    </div>
                  </Col>
                </Row>
              </Form>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
};

export default CreatePin;
