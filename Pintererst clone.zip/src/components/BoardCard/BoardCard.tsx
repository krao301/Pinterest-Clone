import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Board } from '../../types';
import './BoardCard.css';

interface BoardCardProps {
  board: Board;
}

const BoardCard: React.FC<BoardCardProps> = ({ board }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/board/${board.id}`);
  };

  return (
    <div className="board-card" onClick={handleClick}>
      <div className="board-card-cover">
        {board.coverImage ? (
          <img src={board.coverImage} alt={board.title} />
        ) : (
          <div className="board-placeholder">
            <i className="bi bi-collection fs-1"></i>
          </div>
        )}
      </div>
      <div className="board-card-body">
        <h5 className="board-card-title">{board.title}</h5>
        {board.description && (
          <p className="board-card-description">{board.description}</p>
        )}
        <div className="board-card-meta">
          <span className="me-2">
            <i className="bi bi-pin-angle me-1"></i>
            {board.pinCount} pins
          </span>
          <span>
            <i className={`bi ${board.isPublic ? 'bi-globe' : 'bi-lock'} me-1`}></i>
            {board.isPublic ? 'Public' : 'Private'}
          </span>
        </div>
      </div>
    </div>
  );
};

export default BoardCard;
