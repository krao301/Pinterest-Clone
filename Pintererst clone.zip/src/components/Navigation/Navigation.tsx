import React, { useState } from 'react';
import { Navbar, Nav, Container, Form, InputGroup, Button, Dropdown, NavDropdown } from 'react-bootstrap';
import { useNavigate, Link } from 'react-router-dom';
import { authService } from '../../services/authService';
import './Navigation.css';

const Navigation: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const currentUser = authService.getCurrentUser();
  const isAuthenticated = authService.isAuthenticated();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  // Temporarily bypass authentication for development without backend
  // if (!isAuthenticated) {
  //   return null;
  // }

  return (
    <Navbar bg="white" expand="lg" className="navigation-bar shadow-sm sticky-top">
      <Container fluid>
        <Navbar.Brand as={Link} to="/dashboard" className="brand-logo">
          Pinterest
        </Navbar.Brand>

        <Nav className="me-auto d-none d-lg-flex">
          <Nav.Link as={Link} to="/dashboard" className="nav-item-custom">
            <i className="bi bi-house-door-fill me-1"></i>
            Home
          </Nav.Link>
          <Nav.Link as={Link} to="/explore" className="nav-item-custom">
            <i className="bi bi-compass me-1"></i>
            Explore
          </Nav.Link>
          <Nav.Link as={Link} to="/pin/create" className="nav-item-custom">
            <i className="bi bi-plus-circle me-1"></i>
            Create
          </Nav.Link>
        </Nav>

        <Form className="flex-grow-1 mx-3 d-none d-md-block" onSubmit={handleSearch}>
          <InputGroup>
            <InputGroup.Text>
              <i className="bi bi-search"></i>
            </InputGroup.Text>
            <Form.Control
              type="text"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </InputGroup>
        </Form>

        <Nav className="ms-auto align-items-center">
          <Nav.Link as={Link} to="/notifications" className="nav-icon">
            <i className="bi bi-bell fs-5"></i>
          </Nav.Link>
          <Nav.Link as={Link} to="/messages" className="nav-icon">
            <i className="bi bi-chat fs-5"></i>
          </Nav.Link>

          <NavDropdown
            title={
              <span className="user-avatar-nav">
                {currentUser?.profileImage ? (
                  <img src={currentUser.profileImage} alt={currentUser.username} />
                ) : (
                  <i className="bi bi-person-circle fs-4"></i>
                )}
              </span>
            }
            id="user-dropdown"
            align="end"
          >
            <Dropdown.ItemText>
              <strong>{currentUser?.username}</strong>
            </Dropdown.ItemText>
            <Dropdown.Divider />
            <Dropdown.Item as={Link} to={`/profile/${currentUser?.id}`}>
              <i className="bi bi-person me-2"></i>
              Profile
            </Dropdown.Item>
            <Dropdown.Item as={Link} to="/boards">
              <i className="bi bi-collection me-2"></i>
              My Boards
            </Dropdown.Item>
            <Dropdown.Item as={Link} to="/saved">
              <i className="bi bi-bookmark me-2"></i>
              Saved
            </Dropdown.Item>
            <Dropdown.Item as={Link} to="/invitations">
              <i className="bi bi-envelope me-2"></i>
              Invitations
            </Dropdown.Item>
            <Dropdown.Divider />
            <Dropdown.Item as={Link} to="/settings">
              <i className="bi bi-gear me-2"></i>
              Settings
            </Dropdown.Item>
            {currentUser?.isBusinessAccount && (
              <>
                <Dropdown.Divider />
                <Dropdown.Item as={Link} to="/business">
                  <i className="bi bi-briefcase me-2"></i>
                  Business Account
                </Dropdown.Item>
              </>
            )}
            <Dropdown.Divider />
            <Dropdown.Item onClick={handleLogout} className="text-danger">
              <i className="bi bi-box-arrow-right me-2"></i>
              Log Out
            </Dropdown.Item>
          </NavDropdown>
        </Nav>
      </Container>
    </Navbar>
  );
};

export default Navigation;
