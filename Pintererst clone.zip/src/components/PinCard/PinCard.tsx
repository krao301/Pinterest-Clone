import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Pin } from '../../types';
import './PinCard.css';

interface PinCardProps {
  pin: Pin;
}

const PinCard: React.FC<PinCardProps> = ({ pin }) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/pin/${pin.id}`);
  };

  return (
    <div className="pin-card" onClick={handleClick}>
      {pin.isSponsored && <span className="sponsored-label">Sponsored</span>}
      <img
        src={pin.imageUrl}
        alt={pin.title}
        loading="lazy"
        onError={(e) => {
          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/300x400?text=Image+Not+Found';
        }}
      />
      <div className="pin-card-overlay">
        <div className="pin-card-title">{pin.title}</div>
        <div className="pin-card-username">@{pin.username}</div>
      </div>
    </div>
  );
};

export default PinCard;
