import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, Button } from 'react-bootstrap';
import { User } from '../../types';
import { socialService } from '../../services/socialService';
import './UserCard.css';

interface UserCardProps {
  user: User;
}

const UserCard: React.FC<UserCardProps> = ({ user }) => {
  const navigate = useNavigate();
  const [following, setFollowing] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleFollow = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setLoading(true);
    try {
      if (following) {
        await socialService.unfollowUser(user.id);
        setFollowing(false);
      } else {
        await socialService.followUser(user.id);
        setFollowing(true);
      }
    } catch (error) {
      console.error('Error toggling follow:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleClick = () => {
    navigate(`/profile/${user.id}`);
  };

  return (
    <Card className="user-card" onClick={handleClick}>
      <Card.Body className="text-center">
        <div className="user-avatar-large mb-3">
          {user.profileImage ? (
            <img src={user.profileImage} alt={user.username} />
          ) : (
            <i className="bi bi-person-circle fs-1"></i>
          )}
        </div>
        <h5 className="user-card-username">{user.username}</h5>
        {user.bio && <p className="user-card-bio">{user.bio}</p>}
        {user.isBusinessAccount && (
          <span className="badge bg-primary mb-2">
            <i className="bi bi-briefcase me-1"></i>
            Business
          </span>
        )}
        <Button
          variant={following ? 'outline-secondary' : 'danger'}
          size="sm"
          onClick={handleFollow}
          disabled={loading}
          className="w-100"
        >
          {following ? 'Following' : 'Follow'}
        </Button>
      </Card.Body>
    </Card>
  );
};

export default UserCard;
