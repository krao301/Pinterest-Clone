// User types
export interface User {
  id: string;
  username: string;
  email: string;
  profileImage?: string;
  bio?: string;
  isBusinessAccount?: boolean;
  createdAt: string;
}

export interface RegisterRequest {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

// Pin types
export interface Pin {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  sourceUrl?: string;
  isPublic: boolean;
  userId: string;
  username: string;
  boardId?: string;
  createdAt: string;
  updatedAt: string;
  likes: number;
  isSponsored?: boolean;
}

export interface CreatePinRequest {
  title: string;
  description: string;
  imageUrl: string;
  sourceUrl?: string;
  isPublic: boolean;
  boardId?: string;
}

export interface UpdatePinRequest {
  title?: string;
  description?: string;
  imageUrl?: string;
  sourceUrl?: string;
  isPublic?: boolean;
  boardId?: string;
}

// Board types
export interface Board {
  id: string;
  title: string;
  description: string;
  coverImage?: string;
  isPublic: boolean;
  userId: string;
  username: string;
  collaborators?: string[];
  pinCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface CreateBoardRequest {
  title: string;
  description: string;
  isPublic: boolean;
}

export interface UpdateBoardRequest {
  title?: string;
  description?: string;
  isPublic?: boolean;
  coverImage?: string;
}

// Search types
export interface SearchFilters {
  query: string;
  type?: 'pins' | 'boards' | 'users' | 'all';
  sortBy?: 'relevance' | 'date' | 'popularity';
  dateRange?: 'all' | 'today' | 'week' | 'month' | 'year';
}

export interface SearchResults {
  pins: Pin[];
  boards: Board[];
  users: User[];
}

// Social types
export interface Follow {
  id: string;
  followerId: string;
  followingId: string;
  createdAt: string;
}

export interface Invitation {
  id: string;
  boardId: string;
  boardTitle: string;
  fromUserId: string;
  fromUsername: string;
  toUserId: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: string;
}

export interface CollaborationRequest {
  boardId: string;
  userId: string;
}

// Business Account types
export interface BusinessProfile {
  id: string;
  userId: string;
  businessName: string;
  description: string;
  website?: string;
  contactEmail: string;
  logo?: string;
  isVerified: boolean;
  createdAt: string;
}

export interface SponsoredPin extends Pin {
  campaignId: string;
  campaignName: string;
  brandName: string;
  targetUrl: string;
}

export interface Campaign {
  id: string;
  name: string;
  description: string;
  businessId: string;
  budget: number;
  startDate: string;
  endDate: string;
  status: 'active' | 'paused' | 'completed';
  sponsoredPins: string[];
}

// API Response types
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface ApiError {
  success: false;
  message: string;
  errors?: { [key: string]: string };
}

// Pagination types
export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}

// Circuit Breaker types
export interface CircuitBreakerState {
  isOpen: boolean;
  remainingTime: number;
  failedAttempts: number;
}
