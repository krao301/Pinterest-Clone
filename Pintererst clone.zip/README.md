# Pinterest Clone - Frontend

A full-featured Pinterest clone frontend built with React, TypeScript, HTML5, CSS3, and Bootstrap with OAuth authentication.

## Features

### 1. User Authentication (US 01 & US 02)
- **Registration Page** with comprehensive validation:
  - Email format validation (must end with .com, .org, or .in)
  - Username validation (lowercase letters, digits, special characters only)
  - Password validation (8-16 characters, must include uppercase, lowercase, digit, and special character)
  - Confirm password with real-time match checking
- **Login Page** with circuit breaker pattern:
  - 3 failed attempts within 30 seconds triggers circuit breaker
  - 60-second countdown timer displayed when circuit is open
  - Automatic reset after timeout

### 2. Pin Management (US 03 & US 04)
- **Create Pin Page**:
  - Image upload with preview
  - Title, description, and source URL fields
  - Public/Private visibility toggle
  - Board selection dropdown
  - Save as draft functionality
  - Preview before publishing
- **Pin Detail Page**:
  - Full image display with metadata
  - Like/Unlike functionality
  - Edit and delete options (for pin owners)
  - Share functionality
  - Source URL link
  - Sponsored badge for sponsored pins

### 3. Board Management (US 04)
- **Board Detail Page**:
  - Cover image display
  - Board title, description, and metadata
  - Pins organized in masonry layout
  - Edit and delete board options
  - Pin count display
  - Public/Private indicator
- **Board Card Component**:
  - Board cover image
  - Pin count
  - Visibility status

### 4. Search and Discovery (US 05)
- **Search Page**:
  - Real-time search suggestions
  - Search by pins, boards, and users
  - Filter by type (All, Pins, Boards, People)
  - Sort options (Relevance, Date, Popularity)
  - Results displayed in appropriate layouts

### 5. Dashboard/Home Feed
- **Main Dashboard**:
  - Masonry layout for pins
  - Sponsored pins integrated into feed
  - Infinite scroll with "Load More" button
  - Lazy loading for images
  - Responsive design for all screen sizes

### 6. Social Features (US 06 & US 07)
- **Profile Page**:
  - User avatar and bio
  - Follower/Following counts
  - Pin and board tabs
  - Follow/Unfollow button
  - Edit profile option
- **Invitations Page**:
  - View board collaboration invitations
  - Accept/Decline functionality
  - Pending and processed invitations sections
  - Board details with each invitation

### 7. Business Account Features (US 08 & US 09)
- **Business Dashboard**:
  - Business profile information
  - Campaign management
  - Sponsored pins overview
  - Analytics section (placeholder)
  - Performance metrics display
  - Create and manage advertising campaigns
- **Sponsored Pins**:
  - Clearly marked with "Sponsored" label
  - Integrated into main feed
  - Link to brand website
  - Campaign details

### 8. Navigation
- **Top Navigation Bar**:
  - Pinterest logo/brand
  - Home, Explore, Create links
  - Search bar
  - Notifications icon
  - Messages icon
  - User profile dropdown with:
    - Profile link
    - My Boards
    - Saved items
    - Invitations
    - Settings
    - Business Account (if applicable)
    - Logout option (US 10)

## Technology Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **React Router v6** - Client-side routing
- **Bootstrap 5** - UI components and responsive design
- **React Bootstrap** - Bootstrap components for React
- **Axios** - HTTP client for API calls
- **Bootstrap Icons** - Icon library
- **CSS3** - Custom styling

## Project Structure

```
frontend/
├── public/
│   ├── index.html
│   └── manifest.json
├── src/
│   ├── components/
│   │   ├── Navigation/
│   │   │   ├── Navigation.tsx
│   │   │   └── Navigation.css
│   │   ├── PinCard/
│   │   │   ├── PinCard.tsx
│   │   │   └── PinCard.css
│   │   ├── BoardCard/
│   │   │   ├── BoardCard.tsx
│   │   │   └── BoardCard.css
│   │   └── UserCard/
│   │       ├── UserCard.tsx
│   │       └── UserCard.css
│   ├── pages/
│   │   ├── Auth/
│   │   │   ├── Login.tsx
│   │   │   ├── Register.tsx
│   │   │   └── Auth.css
│   │   ├── Dashboard/
│   │   │   ├── Dashboard.tsx
│   │   │   └── Dashboard.css
│   │   ├── Pin/
│   │   │   ├── CreatePin.tsx
│   │   │   ├── PinDetail.tsx
│   │   │   └── Pin.css
│   │   ├── Board/
│   │   │   ├── BoardDetail.tsx
│   │   │   └── Board.css
│   │   ├── Search/
│   │   │   ├── Search.tsx
│   │   │   └── Search.css
│   │   ├── Profile/
│   │   │   ├── Profile.tsx
│   │   │   └── Profile.css
│   │   ├── Social/
│   │   │   ├── Invitations.tsx
│   │   │   └── Invitations.css
│   │   └── Business/
│   │       ├── BusinessDashboard.tsx
│   │       └── BusinessDashboard.css
│   ├── services/
│   │   ├── apiService.ts
│   │   ├── authService.ts
│   │   ├── pinService.ts
│   │   ├── boardService.ts
│   │   ├── searchService.ts
│   │   ├── socialService.ts
│   │   └── businessService.ts
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── App.css
│   ├── index.tsx
│   └── index.css
├── .env
├── .gitignore
├── package.json
├── tsconfig.json
└── README.md
```

## Setup Instructions

### Prerequisites
- Node.js 16+ installed
- npm or yarn package manager

### Installation

1. Navigate to the frontend directory:
```bash
cd "Pinterest Clone/frontend"
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
Edit the `.env` file in the frontend directory:
```env
REACT_APP_API_BASE_URL=http://localhost:8080/api
REACT_APP_OAUTH_CLIENT_ID=your-client-id
REACT_APP_OAUTH_REDIRECT_URI=http://localhost:3000/callback
REACT_APP_OAUTH_AUTHORIZATION_ENDPOINT=http://localhost:8080/oauth/authorize
REACT_APP_OAUTH_TOKEN_ENDPOINT=http://localhost:8080/oauth/token
```

4. Start the development server:
```bash
npm start
```

The application will open in your browser at `http://localhost:3000`

### Build for Production

```bash
npm run build
```

This creates an optimized production build in the `build` folder.

## API Integration

The frontend communicates with the backend microservices through the following services:

- **Authentication Service** - User registration, login, profile management
- **Pin Service** - Create, read, update, delete pins
- **Board Service** - Manage boards and board collaborations
- **Search Service** - Search pins, boards, and users
- **Social Service** - Follow/unfollow, invitations, followers/following
- **Business Service** - Business profiles, campaigns, sponsored pins

All API calls include:
- JWT token authentication (stored in localStorage)
- Automatic token injection via Axios interceptors
- Error handling with user-friendly messages
- Automatic redirect to login on 401 errors

## Key Features Implementation

### Circuit Breaker Pattern (Login)
- Tracks failed login attempts
- Opens circuit after 3 failures within 30 seconds
- Displays countdown timer for 60 seconds
- Stores state in localStorage for persistence
- Auto-resets after timeout

### Validation
- Email: Must match pattern with .com/.org/.in domains
- Username: Lowercase letters, digits, special characters only
- Password: 8-16 chars, must include uppercase, lowercase, digit, special character
- Real-time validation feedback

### Responsive Design
- Mobile-first approach
- Breakpoints for mobile, tablet, and desktop
- Masonry layout for pins (1-5 columns based on screen size)
- Touch-friendly buttons and interactions
- Bootstrap grid system

### Image Lazy Loading
- Images load as they enter viewport
- Reduces initial page load time
- Smooth user experience
- Placeholder images for failed loads

### OAuth Integration
- Ready for OAuth 2.0 implementation
- Environment variables for OAuth configuration
- Protected routes for authenticated users
- Public routes redirect to dashboard if logged in

## User Stories Coverage

✅ **US 01: User Registration** - Complete with validation  
✅ **US 02: Login** - Complete with circuit breaker  
✅ **US 03: Create Pin** - Complete with draft and preview  
✅ **US 04: Retrieval of Pins and Boards** - Complete with detailed views  
✅ **US 05: Search Pins and Boards** - Complete with filters and suggestions  
✅ **US 06: Follow/Unfollow** - Complete with follower lists  
✅ **US 07: View Invitations** - Complete with accept/decline  
✅ **US 08: Business Profiles** - Complete with dashboard  
✅ **US 09: Advertising Campaigns** - Complete with sponsored pins  
✅ **US 10: Log Out** - Complete with session cleanup  

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

This is a project implementation based on the Pinterest-QP.txt requirements document.

## License

This is an educational project.
